package project;
public class PriceCal {
public static double usedprice(double milage,double newprice){
        double usedprice=0;
        double Milage[]={0,5000,15000,30000,50000,70000,100000};
        if (milage>=Milage[0]&&milage<=Milage[1]) {
            usedprice+=(newprice*(95/100.0));
        }
        else if (milage>=Milage[1]&&milage<=Milage[2]) {
            usedprice+=(newprice*(90/100.0));
        }
        else if (milage>=Milage[2]&&milage<=Milage[3]) {
            usedprice+=(newprice*(85/100.0));
        }
        else if (milage>=Milage[3]&&milage<=Milage[4]) {
            usedprice+=(newprice*(75/100.0));
        }
       else if (milage>=Milage[4]&&milage<=Milage[5]) {
            usedprice+=(newprice*(65/100.0));
        }
       else if (milage>=Milage[5]&&milage<=Milage[6]) {
            usedprice+=(newprice*(50/100.0));
        }
        return usedprice;
    }    
}
