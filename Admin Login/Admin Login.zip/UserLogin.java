package project;
import java.awt.Dimension;
import java.io.*;
import java.util.Scanner;
import javax.swing.JOptionPane;
public class UserLogin extends javax.swing.JFrame {
    private static final String FILENAME = "test.txt";
    private boolean check1 = false;
    private boolean check2 = false;
    private boolean check3 = false;
    private boolean check4 = false;
    public UserLogin() {
        initComponents();
        this.setMinimumSize(new Dimension(1140, 690));
         this.setLocationRelativeTo(null);
        Name.setBackground(new java.awt.Color(255, 255, 255,200));
        Passward.setBackground(new java.awt.Color(255, 255, 255,200));
        cnic.setBackground(new java.awt.Color(255, 255, 255,200));
        email.setBackground(new java.awt.Color(255, 255, 255,200));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        saveName = new javax.swing.JButton();
        BuyCar = new javax.swing.JButton();
        PriceCal = new javax.swing.JButton();
        Back = new javax.swing.JButton();
        Field = new javax.swing.JTextField();
        Name = new javax.swing.JPanel();
        User = new javax.swing.JLabel();
        Passward = new javax.swing.JPanel();
        Pass = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        save1 = new javax.swing.JButton();
        Field1 = new javax.swing.JTextField();
        email = new javax.swing.JPanel();
        Pass1 = new javax.swing.JLabel();
        cnic = new javax.swing.JPanel();
        cnicl = new javax.swing.JLabel();
        Field2 = new javax.swing.JTextField();
        save3 = new javax.swing.JButton();
        save2 = new javax.swing.JButton();
        Field3 = new javax.swing.JTextField();
        Save1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        saveName.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        saveName.setText("Save");
        saveName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveNameActionPerformed(evt);
            }
        });
        getContentPane().add(saveName);
        saveName.setBounds(550, 50, 90, 40);

        BuyCar.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        BuyCar.setText("Buy Car");
        BuyCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuyCarActionPerformed(evt);
            }
        });
        getContentPane().add(BuyCar);
        BuyCar.setBounds(290, 330, 180, 60);

        PriceCal.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        PriceCal.setText("Price Calculator");
        PriceCal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PriceCalActionPerformed(evt);
            }
        });
        getContentPane().add(PriceCal);
        PriceCal.setBounds(580, 320, 210, 70);

        Back.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });
        getContentPane().add(Back);
        Back.setBounds(110, 510, 160, 60);

        Field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FieldActionPerformed(evt);
            }
        });
        getContentPane().add(Field);
        Field.setBounds(340, 50, 150, 40);

        Name.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        User.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        User.setText("User Name");
        Name.add(User, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, -2, 110, 40));

        getContentPane().add(Name);
        Name.setBounds(130, 50, 160, 40);

        Passward.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pass.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        Pass.setText("Phone Number");
        Passward.add(Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 160, 20));

        getContentPane().add(Passward);
        Passward.setBounds(130, 120, 160, 40);

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jButton5.setText("Quit");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(890, 520, 160, 60);

        save1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        save1.setText("Save");
        save1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save1ActionPerformed(evt);
            }
        });
        getContentPane().add(save1);
        save1.setBounds(550, 120, 90, 40);
        getContentPane().add(Field1);
        Field1.setBounds(340, 120, 150, 40);

        email.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Pass1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        Pass1.setText("Email Adress");
        email.add(Pass1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 160, 20));

        getContentPane().add(email);
        email.setBounds(130, 260, 170, 40);

        cnic.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cnicl.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        cnicl.setText("CNIC");
        cnic.add(cnicl, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 8, 110, -1));

        getContentPane().add(cnic);
        cnic.setBounds(130, 190, 170, 40);

        Field2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Field2ActionPerformed(evt);
            }
        });
        getContentPane().add(Field2);
        Field2.setBounds(340, 190, 150, 40);

        save3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        save3.setText("Save");
        save3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save3ActionPerformed(evt);
            }
        });
        getContentPane().add(save3);
        save3.setBounds(550, 260, 90, 40);

        save2.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        save2.setText("Save");
        save2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save2ActionPerformed(evt);
            }
        });
        getContentPane().add(save2);
        save2.setBounds(550, 190, 90, 40);

        Field3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Field3ActionPerformed(evt);
            }
        });
        getContentPane().add(Field3);
        Field3.setBounds(340, 260, 150, 40);

        Save1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        Save1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/User.jpeg"))); // NOI18N
        getContentPane().add(Save1);
        Save1.setBounds(-30, -10, 1180, 710);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        this.dispose();
        FirstWindow f = new FirstWindow();
        f.setVisible(true);
    }//GEN-LAST:event_BackActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       System.exit(0);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void PriceCalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PriceCalActionPerformed
        this.dispose();
        Calculator p = new Calculator();
        p.setVisible(true);
    }//GEN-LAST:event_PriceCalActionPerformed

    private void BuyCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuyCarActionPerformed
       if(check1 && check2 && check3 && check4){ 
       this.dispose();
       Brands b = new Brands();
       b.setVisible(true);
        }
        if(!check1){
            String out="Please Enter your Name";
            JOptionPane.showMessageDialog(null, out);
        }
        else if(!check2){
            String out="Please Enter your Phone Number";
            JOptionPane.showMessageDialog(null, out);
        }
        else if(!check3){
            String out="Please Enter your CNIC";
            JOptionPane.showMessageDialog(null, out);
        }
        else if(!check4){
            String out="Please Enter your Email Adress";
            JOptionPane.showMessageDialog(null, out);
        }   
    }//GEN-LAST:event_BuyCarActionPerformed
    
    private void saveNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveNameActionPerformed
            BufferedWriter bw = null;
            FileWriter fw = null;
            try {
                String data = "Name: " + Field.getText() + " ";;
                File file = new File(FILENAME);
                // if file doesnt exists, then create it
                if (!file.exists()) {
                    file.createNewFile();
                }
                fw = new FileWriter(file.getAbsoluteFile(), true);
                bw = new BufferedWriter(fw);
                bw.write(data);
                bw.newLine();
                System.out.println("Done");
                Field.setText("");
                check1 = true;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (bw != null) {
                        bw.close();
                    }
                    if (fw != null) {
                        fw.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }  
    }//GEN-LAST:event_saveNameActionPerformed
    private void save2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save2ActionPerformed
            BufferedWriter bw = null;
            FileWriter fw = null;
            boolean check = checkCnic();
            boolean check1 = checkDash();
            if(check1){
                String out="CNIC should not include dashes";
                JOptionPane.showMessageDialog(null, out);
            }
            if(!check){
                String out="Invalid CNIC";
                JOptionPane.showMessageDialog(null, out);
            }else{
            try {
                String data = "CNIC: " + Field2.getText() + " ";;
                File file = new File(FILENAME);
                // if file doesnt exists, then create it
                if (!file.exists()) {
                    file.createNewFile();
                }
                fw = new FileWriter(FILENAME, true);
                bw = new BufferedWriter(fw);
                bw.write(data);
                bw.newLine();
                System.out.println("Done");
                Field2.setText("");
                check3 = true;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (bw != null) {
                        bw.close();
                       // fw.close();
                    }
                    if (fw != null) {
                        fw.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }  
            }
    }//GEN-LAST:event_save2ActionPerformed

    private void FieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FieldActionPerformed
       
    }//GEN-LAST:event_FieldActionPerformed

    private void save1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save1ActionPerformed
          BufferedWriter bw = null;
            FileWriter fw = null;
            boolean check = checkPh();
            if(!check){
                String out="Invalid Phone Number";
                JOptionPane.showMessageDialog(null, out);
            }else{
            try {
                String data = "Phone NO: " + Field1.getText() + " ";;
                File file = new File(FILENAME);
                // if file doesnt exists, then create it
                if (!file.exists()) {
                    file.createNewFile();
                }
                fw = new FileWriter(file.getAbsoluteFile(), true);
                bw = new BufferedWriter(fw);
                bw.write(data);
                bw.newLine();
                System.out.println("Done");
                Field1.setText("");
                check2 = true;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (bw != null) {
                        bw.close();
                    }
                    if (fw != null) {
                        fw.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }  
            }
    }//GEN-LAST:event_save1ActionPerformed

    private void save3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save3ActionPerformed
        BufferedWriter bw = null;
            FileWriter fw = null;
            boolean check = checkMail();
            if(!check){
                    String out="Wrong Email Adress ";
                    JOptionPane.showMessageDialog(null, out);
        }else{
            try {
                String data = "Email: " + Field3.getText() + " ";;
                File file = new File(FILENAME);
                // if file doesnt exists, then create it
                if (!file.exists()) {
                    file.createNewFile();
                }
                fw = new FileWriter(file.getAbsoluteFile(), true);
                bw = new BufferedWriter(fw);
                bw.write(data);
                bw.newLine();
                System.out.println("Done");
                Field3.setText("");
                check4 = true;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (bw != null) {
                        bw.close();
                    }
                    if (fw != null) {
                        fw.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }  
        
            }
    }//GEN-LAST:event_save3ActionPerformed

    private void Field2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Field2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Field2ActionPerformed

    private void Field3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Field3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Field3ActionPerformed
    public  boolean checkMail(){
        boolean check = false;
        String s = Field3.getText();
        for (int i = 0; i < s.length(); i++) {
            if(s.charAt(i) == '@'){
                check = true;
                break;
            }
        }
        return check;
    }
    public boolean checkCnic(){
        boolean check = false;
        int count = 0;
        String s = Field2.getText();
        for (int i = 0; i < s.length(); i++) {
            count++;
        }
        if(count == 13 ){
            check = true;
        }
        return check;
    }
    public boolean checkDash(){
        boolean check = false;
        String s = Field2.getText();
        for (int i = 0; i < s.length(); i++) {
            if(s.charAt(i) == '-'){
                check = true;
                break;
            }
                }
        return check;
    }
    public boolean checkPh(){
        boolean check = false;
        int count = 0;
        String s = Field1.getText();
        for (int i = 0; i < s.length(); i++) {
            count++;
        }
        if(count == 11 ){
            check = true;
        }
        return check;
        }
    
    
 
  
    public static void main(String args[]) throws IOException  {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserLogin().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JButton BuyCar;
    private javax.swing.JTextField Field;
    private javax.swing.JTextField Field1;
    private javax.swing.JTextField Field2;
    private javax.swing.JTextField Field3;
    private javax.swing.JPanel Name;
    private javax.swing.JLabel Pass;
    private javax.swing.JLabel Pass1;
    private javax.swing.JPanel Passward;
    private javax.swing.JButton PriceCal;
    private javax.swing.JLabel Save1;
    private javax.swing.JLabel User;
    private javax.swing.JPanel cnic;
    private javax.swing.JLabel cnicl;
    private javax.swing.JPanel email;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton save1;
    private javax.swing.JButton save2;
    private javax.swing.JButton save3;
    private javax.swing.JButton saveName;
    // End of variables declaration//GEN-END:variables
}
