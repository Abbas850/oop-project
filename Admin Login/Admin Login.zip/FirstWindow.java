package project;
import java.awt.*;
public class FirstWindow extends javax.swing.JFrame {
    public FirstWindow() {
        initComponents();
        this.setMinimumSize(new Dimension(1140, 690));
        this.setLocationRelativeTo(null);
        labelPanel.setBackground(new java.awt.Color(255, 255, 255,200));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        User = new javax.swing.JButton();
        Admin = new javax.swing.JButton();
        labelPanel = new javax.swing.JPanel();
        Label = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        BackgroundLabel = new javax.swing.JLabel();

        jButton2.setText("jButton2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setMaximumSize(new java.awt.Dimension(1140, 690));
        setMinimumSize(new java.awt.Dimension(1140, 690));
        setPreferredSize(new java.awt.Dimension(1140, 690));
        getContentPane().setLayout(null);

        User.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        User.setText("User Login");
        User.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserActionPerformed(evt);
            }
        });
        getContentPane().add(User);
        User.setBounds(470, 300, 170, 70);

        Admin.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        Admin.setText("Admin Login");
        Admin.setMaximumSize(new java.awt.Dimension(83, 23));
        Admin.setMinimumSize(new java.awt.Dimension(83, 23));
        Admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminActionPerformed(evt);
            }
        });
        getContentPane().add(Admin);
        Admin.setBounds(470, 410, 170, 70);

        labelPanel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        Label.setFont(new java.awt.Font("Perpetua Titling MT", 1, 24)); // NOI18N
        Label.setText("Car ShowRoom Management System");

        javax.swing.GroupLayout labelPanelLayout = new javax.swing.GroupLayout(labelPanel);
        labelPanel.setLayout(labelPanelLayout);
        labelPanelLayout.setHorizontalGroup(
            labelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(labelPanelLayout.createSequentialGroup()
                .addComponent(Label, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 3, Short.MAX_VALUE))
        );
        labelPanelLayout.setVerticalGroup(
            labelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(labelPanelLayout.createSequentialGroup()
                .addComponent(Label, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 4, Short.MAX_VALUE))
        );

        getContentPane().add(labelPanel);
        labelPanel.setBounds(250, 110, 590, 130);

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton4.setText("Quit");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(930, 530, 130, 60);

        BackgroundLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/Price.jpeg"))); // NOI18N
        getContentPane().add(BackgroundLabel);
        BackgroundLabel.setBounds(0, 0, 1130, 680);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserActionPerformed
        this.dispose();
        UserLogin obj = new UserLogin();
        obj.setVisible(true);
    }//GEN-LAST:event_UserActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
      System.exit(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void AdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminActionPerformed
        this.dispose();
        AdminLogin l = new AdminLogin();
        l.setVisible(true);
    }//GEN-LAST:event_AdminActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FirstWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Admin;
    private javax.swing.JLabel BackgroundLabel;
    private javax.swing.JLabel Label;
    private javax.swing.JButton User;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JPanel labelPanel;
    // End of variables declaration//GEN-END:variables
}
