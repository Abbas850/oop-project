
package project;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
public class Mehran extends javax.swing.JFrame {
private boolean check;
private boolean checkF;
    public Mehran() {
        initComponents();
        this.setMinimumSize(new Dimension(1140, 690));
        this.setLocationRelativeTo(null);
        LabelPanel.setBackground(new java.awt.Color(255, 255, 255,150));
      //  TextLabel1.setBackground(new java.awt.Color(255, 255, 255,200));
      //  TextLabel2.setBackground(new java.awt.Color(255, 255, 255,200));
     //  TextLabel3.setBackground(new java.awt.Color(255, 255, 255,200));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LabelPanel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        TextLabel2 = new javax.swing.JPanel();
        CheckCash = new javax.swing.JCheckBox();
        jLabel4 = new javax.swing.JLabel();
        TextLabel1 = new javax.swing.JPanel();
        CheckCard = new javax.swing.JCheckBox();
        jLabel5 = new javax.swing.JLabel();
        TextLabel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cardField = new javax.swing.JTextField();
        save = new javax.swing.JButton();
        back = new javax.swing.JButton();
        quit = new javax.swing.JButton();
        prchaseCar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        LabelPanel.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 24)); // NOI18N
        jLabel2.setText("Price For Suzuki Mehran is 750,000");
        LabelPanel.add(jLabel2);
        jLabel2.setBounds(10, 0, 470, 60);

        getContentPane().add(LabelPanel);
        LabelPanel.setBounds(320, 50, 490, 70);

        TextLabel2.setLayout(null);

        CheckCash.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        CheckCash.setText("Purchase through Cash");
        CheckCash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckCashActionPerformed(evt);
            }
        });
        TextLabel2.add(CheckCash);
        CheckCash.setBounds(10, 10, 270, 33);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel4.setText(" 10% Down Payment");
        TextLabel2.add(jLabel4);
        jLabel4.setBounds(10, 40, 260, 20);

        getContentPane().add(TextLabel2);
        TextLabel2.setBounds(150, 210, 280, 70);

        TextLabel1.setLayout(null);

        CheckCard.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        CheckCard.setText("Purchase through Installments");
        CheckCard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckCardActionPerformed(evt);
            }
        });
        TextLabel1.add(CheckCard);
        CheckCard.setBounds(10, 10, 350, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel5.setText("25% Advance Payment");
        TextLabel1.add(jLabel5);
        jLabel5.setBounds(20, 40, 240, 30);

        getContentPane().add(TextLabel1);
        TextLabel1.setBounds(690, 210, 360, 70);

        TextLabel3.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel3.setText("Enter Debit Card Number:");
        TextLabel3.add(jLabel3);
        jLabel3.setBounds(10, 0, 240, 40);

        getContentPane().add(TextLabel3);
        TextLabel3.setBounds(150, 340, 270, 40);

        cardField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardFieldActionPerformed(evt);
            }
        });
        getContentPane().add(cardField);
        cardField.setBounds(520, 340, 130, 40);

        save.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        save.setText("Save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save);
        save.setBounds(710, 340, 81, 40);

        back.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back);
        back.setBounds(90, 540, 130, 80);

        quit.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        quit.setText("Quit");
        quit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quitActionPerformed(evt);
            }
        });
        getContentPane().add(quit);
        quit.setBounds(920, 540, 130, 80);

        prchaseCar.setFont(new java.awt.Font("Tahoma", 3, 20)); // NOI18N
        prchaseCar.setText("Purchase Car");
        prchaseCar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prchaseCarActionPerformed(evt);
            }
        });
        getContentPane().add(prchaseCar);
        prchaseCar.setBounds(490, 460, 180, 90);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project/car3.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1140, 690);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CheckCashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckCashActionPerformed
      check = false;
      //cardField.disable();
    }//GEN-LAST:event_CheckCashActionPerformed

    private void cardFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardFieldActionPerformed
     
    }//GEN-LAST:event_cardFieldActionPerformed

    private void CheckCardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckCardActionPerformed
        check = true;
       // cardField.enable();
    }//GEN-LAST:event_CheckCardActionPerformed
    private boolean checkCard(){
        String s = cardField.getText();
        int count = 0;
        boolean check1 = false;
        for (int i = 0; i < s.length(); i++) {
            count++;
        }
        if(count == 16){
            check1 = true;
        }
        return check1;
    }
    private void prchaseCarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prchaseCarActionPerformed
      double down = (10 / 100.0) * 750000;
        if(check && checkF){
        JFrame window = new JFrame();
            window.setSize(700, 300);
            window.setVisible(true);
            window.setLocationRelativeTo(null);
            double fort = (25 / 100.0) * 750000;
            double monthly = (1520000 - fort) / 60;
            JLabel jla = new JLabel("Congragultions!");
            jla.setFont(new Font("Tahoma", Font.BOLD, 30));
            JLabel jl = new JLabel("You Sucessfully purchased the Car");
            jl.setFont(new Font("Tahoma", Font.PLAIN, 30));
            JLabel j2 = new JLabel("Installment for five years are:");
            j2.setFont(new Font("Tahoma", Font.PLAIN, 30));
            JLabel j3 = new JLabel("Advance amount: " + fort);
            j3.setFont(new Font("Tahoma", Font.PLAIN, 30));
            JLabel j4 = new JLabel("Monthly Installment: " + monthly);
            j4.setFont(new Font("Tahoma", Font.PLAIN, 30));
            JPanel jp = new JPanel();
            window.add(jp);
            jp.add(jla);
            jp.add(jl);
            jp.add(j2);
            jp.add(j3);
            jp.add(j4);
       }
        if(!check && checkF)
        {
            JFrame window = new JFrame();
            window.setSize(700, 300);
            window.setVisible(true);
            window.setLocationRelativeTo(null);
            JLabel jl = new JLabel("Congragultions!");
            jl.setFont(new Font("Tahoma", Font.BOLD, 30));
            JLabel j2 = new JLabel("You Hava Sucessfully Booked The Car");
            j2.setFont(new Font("Tahoma", Font.PLAIN, 30));
            JLabel j3 = new JLabel("10% Down Payment : " + down +  " has been Deducted from your accout");
            JLabel j4 = new JLabel("Visit Your nearest dealer to get your Order");
            JPanel jp = new JPanel();
            window.add(jp);
            jp.add(jl);
            jp.add(j2);
            jp.add(j3);
            jp.add(j4);
            }
        if(!checkF){
            String out="Please Enter Your Card Number";
            JOptionPane.showMessageDialog(null, out);
        }
        checkF= false;
    }//GEN-LAST:event_prchaseCarActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
      this.dispose();
      Suzuki s = new Suzuki();
      s.setVisible(true);
    }//GEN-LAST:event_backActionPerformed

    private void quitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quitActionPerformed
       System.exit(0);
    }//GEN-LAST:event_quitActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
       boolean check = checkCard();
       if(!check){
            String out="Invalid Card Number";
            JOptionPane.showMessageDialog(null, out);
       }else{
         {
            BufferedWriter bw = null;
            FileWriter fw = null;
            try {
                String data = "Credit Card# " + cardField.getText() + " ";;
                File file = new File("test.txt");
               // if file doesnt exists, then create it
                if (!file.exists()) {
                    file.createNewFile();
                }
                // true = append file
                fw = new FileWriter(file.getAbsoluteFile(), true);
                bw = new BufferedWriter(fw);
                bw.write(data);
                bw.newLine();
                System.out.println("Done");
                cardField.setText("");
                checkF = true;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (bw != null) {
                        bw.close();
                    }
                    if (fw != null) {
                        fw.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
       }
    }//GEN-LAST:event_saveActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Mehran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Mehran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Mehran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Mehran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Mehran().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox CheckCard;
    private javax.swing.JCheckBox CheckCash;
    private javax.swing.JPanel LabelPanel;
    private javax.swing.JPanel TextLabel1;
    private javax.swing.JPanel TextLabel2;
    private javax.swing.JPanel TextLabel3;
    private javax.swing.JButton back;
    private javax.swing.JTextField cardField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JButton prchaseCar;
    private javax.swing.JButton quit;
    private javax.swing.JButton save;
    // End of variables declaration//GEN-END:variables
}
